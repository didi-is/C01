#!/bin/bash
# Demander à l'utilisateur le nom du dossier
read myfolder

# Vérifier que le dossier existe
repertoire=$(ls "$myfolder" | wc -l)
echo "Le dossier $myfolder contient $repertoire fichier(s)."
